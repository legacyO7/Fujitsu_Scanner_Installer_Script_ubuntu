#!/bin/sh

LOGFILENAME=pfufssysinfo.txt

rm $LOGFILENAME 2>/dev/null
echo "----- system information -----" >>$LOGFILENAME
date >> $LOGFILENAME
uname -a >> $LOGFILENAME
if [ -f /etc/lsb-release ] 
then
  cat /etc/lsb-release >> $LOGFILENAME
fi
echo "----- cpu and memory information -----" >>$LOGFILENAME
cat /proc/cpuinfo >> $LOGFILENAME
cat /proc/meminfo >> $LOGFILENAME
echo "----- usb device information -----" >>$LOGFILENAME
lsusb >> $LOGFILENAME
lsusb -v >> $LOGFILENAME
echo "----- pci information -----" >>$LOGFILENAME
lspci >> $LOGFILENAME
echo "----- dmesg information -----" >>$LOGFILENAME
dmesg >> $LOGFILENAME
echo "----- syslog information -----" >>$LOGFILENAME
cat /var/log/syslog >> $LOGFILENAME




